Contributing
============

If you have something you'd like to contribute, please follow our
[contributing guidelines](https://github.com/eclipse-color-theme/eclipse-color-theme/wiki/Contributing#submitting-a-pull-request).

If you'd like to help but aren't sure how, please read our
[contributor guide](https://github.com/eclipse-color-theme/eclipse-color-theme/wiki/Contributing).
